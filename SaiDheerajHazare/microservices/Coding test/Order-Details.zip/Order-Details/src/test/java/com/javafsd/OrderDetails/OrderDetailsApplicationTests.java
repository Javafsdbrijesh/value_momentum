package com.javafsd.OrderDetails;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderDetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}

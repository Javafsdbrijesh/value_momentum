package com.javafsd.hibernatehelloworldexampledemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HibernateHelloworldExampleDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(HibernateHelloworldExampleDemoApplication.class, args);
	}

}

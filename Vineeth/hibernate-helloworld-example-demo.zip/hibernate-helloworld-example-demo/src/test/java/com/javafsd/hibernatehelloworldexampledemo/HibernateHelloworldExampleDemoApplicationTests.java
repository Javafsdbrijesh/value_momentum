package com.javafsd.hibernatehelloworldexampledemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateHelloworldExampleDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}

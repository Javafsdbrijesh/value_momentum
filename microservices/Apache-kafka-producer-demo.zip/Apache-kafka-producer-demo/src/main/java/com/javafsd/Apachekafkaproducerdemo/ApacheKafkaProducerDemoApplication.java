package com.javafsd.Apachekafkaproducerdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApacheKafkaProducerDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApacheKafkaProducerDemoApplication.class, args);
	}

}

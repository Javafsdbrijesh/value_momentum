package com.javafsd.valuemomentum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValuemomentumApplicationTests {

	@Test
	void contextLoads() {
	}

}

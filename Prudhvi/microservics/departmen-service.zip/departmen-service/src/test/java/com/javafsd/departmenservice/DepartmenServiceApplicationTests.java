package com.javafsd.departmenservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DepartmenServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
